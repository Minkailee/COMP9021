# Code for insertion into a priority queue
# implemented as a binary tree
#
# Written by minkaili for COMP9021


from binary_tree import *
from math import log


class PriorityQueue(BinaryTree):
    def __init__(self):
        super().__init__()

    def insert(self, value):
        if self.value is None:
            self.value = value
            self.left_node = PriorityQueue()
            self.right_node = PriorityQueue()
            return True
        if value < self.value:
            value,self.value=self.value,value
        if self.right_node.value is None:
            if self.left_node.value is None:
                self.left_node.insert(value)
            else:
                self.right_node.insert(value)
        elif value<self.left_node.value or value>self.right_node.value:
            self.left_node.insert(value)
        elif value>=self.left_node.value and value<=self.right_node.value:
            self.right_node.insert(value)
        
        pass
        # Replace pass above with your code
